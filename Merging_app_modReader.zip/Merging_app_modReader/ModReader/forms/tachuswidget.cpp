#include "tachuswidget.h"
#include "ui_tachuswidget.h"
#include "sender.h"

#include <QThread>
#include <QDate>
#include <cmath>
#include <QHostInfo>
#include <QNetworkInterface>
#include <QFile>
#include <QFileInfo>
#include <QTextStream>
#include <QCryptographicHash>

#define ENCRYPTION_DEFAULT 3

TachusWidget::TachusWidget(MainWindow *mainwindow, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TachusWidget)
{
    ui->setupUi(this);
    m_mainWindow = mainwindow;

    // for initial connection, do dummy read
    //on_pushButton_clicked();

    m_timer = new QTimer(this);
    //connect(m_timer, SIGNAL(timeout()), this, SLOT(checkForNewShots()));
    //    QDate date = QDate::currentDate();
    //    if (date.dayOfYear() > 150 && date.dayOfYear() < 360 && date.year() == 2019)
    connect(m_timer, SIGNAL(timeout()), this, SLOT(on_pushButton_2_clicked()));
    m_timer->start(100);
    m_motorThread = new MotorThread(m_mainWindow, this);
    m_flushCount = new FlushShootCountThread(m_mainWindow, this);
    changeSighterMode(true); // as the app start with sighter mode
}

TachusWidget::~TachusWidget()
{
    delete ui;
}

void TachusWidget::initialiseConnection()
{
    //    if (!m_mainWindow->isModBusConnected())
    //        m_mainWindow->changedConnect(true);

    //    uint8_t dest[1024]; //setup memory for data
    //    uint16_t * dest16 = (uint16_t *) dest;
    //    memset(dest, 0, 1024);

    //    m_mainWindow->modbusReadRegistry(8192, 2, dest16);
    //    m_currentShootsCount = dest16[1];
    //    m_mainWindow->getTextEdit()->setPlainText(QString("shoots count ******* %1").arg(m_currentShootsCount));
}

bool TachusWidget::isModBusConnected()
{
    bool isConnected = m_mainWindow->isModBusConnected();
    LogFile::instance().appendToLogFile(QString("Checking port connection status -> %1").arg(isConnected), LogType::interfaceLevel);
    return isConnected;
}

bool TachusWidget::isMasterSystemConnected()
{
    return false;
}

bool TachusWidget::connectedModbus(QString portName)
{
    if (portName.isEmpty())
        LogFile::instance().appendToLogFile(QString("connect with port number -> Auto Connect"), LogType::interfaceLevel);
    else
        LogFile::instance().appendToLogFile(QString("connect with port number -> %1").arg(portName), LogType::interfaceLevel);

    if (m_mainWindow == NULL)
        return false;

    if (!m_mainWindow->isModBusConnected())
        m_mainWindow->changedConnect(true, portName);

    if (m_mainWindow->isModBusConnected()) {
        clearShootCount();
        intiateAutoMovementSetup();
    }
}

int TachusWidget::validateLicence(QString mail)
{
    if (mail.isEmpty())
        return 0;

    QFile file("licence.txt");
    QFileInfo fInfo(file);

    //1. check for licence file if not exist return false
    if (!fInfo.exists() || !file.open(QIODevice::ReadOnly))
        return 1;

    //2. check for verified word on last line
    //a. if present, already verified
    //b. if not check for

    QTextStream stream(&file);
    int counter = 0;
    qDebug() << __LINE__;
    while(!stream.atEnd()) {
        QString line = stream.readLine();
        QString code;
        if (counter == 0) {
            code = getDencryptedText(line, "",true);
            line = code;
        } else {
            line = getDencryptedText(line, code, false);
        }
        qDebug() << line << __LINE__;
        QString date = QString("current_date %1").arg(QDate::currentDate().toString("dd/MM/yyyy"));
        if (line.contains("user_mail ") && line.endsWith(mail)) {
            file.close();
            licValidated();
            return 3; // verification success
        } else if (line.contains("current_date ") && !line.endsWith(date)) {
            file.close();
            return 2;
        }

        qDebug() << line;
        counter++;
    }


    file.close();
    return 0;
}

bool TachusWidget::disconnectModbus()
{
    LogFile::instance().appendToLogFile(QString("disconnect port"), LogType::interfaceLevel);
    if (m_mainWindow == NULL)
        return false;

    if (m_mainWindow->isModBusConnected())
        m_mainWindow->changedConnect(false);

    return m_mainWindow->isModBusConnected();
}

void TachusWidget::on_pushButton_clicked()
{
    if (m_mainWindow == NULL)
        return;

    int from = ui->spinBox->value();
    int to = ui->spinBox_2->value();
    //    if (from <= 0 || to <= 0 || from >= to)
    //        return;
    // just to allow initial connection


    if (!m_mainWindow->isModBusConnected())
        m_mainWindow->changedConnect(true);

    if (m_mainWindow->isModBusConnected())
    {
        LogFile::instance().appendToLogFile(QString("Collect data for shoots from %1 to %2").arg(from).arg(to), LogType::interfaceLevel);
        int baseNumber = 16376;

        for (int i=from; i<=to; ++i)
        {
            int newAddress = baseNumber +(8*i);
            m_mainWindow->setSBStartAddValue(newAddress, 0);
            m_mainWindow->request();
        }
    }
}

void TachusWidget::on_pushButton_2_clicked() // read old data
{
    if (m_mainWindow && m_mainWindow->isModBusConnected())
    {
        int from = m_currentShootsCount;
        checkForNewShots();
        int to = m_currentShootsCount;

        if (from < to)
        {
            LogFile::instance().appendToLogFile(QString("Collecting data for shoots from %1 to %2").arg(from).arg(to), LogType::interfaceLevel);
            int baseNumber = 16376;
            for (int i=from+1; i<=to; ++i)
            {
                uint8_t dest[1024]; //setup memory for data
                uint16_t * dest16 = (uint16_t *) dest;
                memset(dest, 0, 1024);

                int newAddress = baseNumber +(8*i);
                m_mainWindow->modbusReadRegistry(newAddress, 2, dest16);
                int x = dest16[1];
                int y = dest16[0];
                double xReal = x < 255 ? x/10.0 : getRealValue(x)/10.0;
                double yReal = y < 255 ? y/10.0 : getRealValue(y)/10.0;
                m_xCordList.append(xReal);
                m_yCordList.append(yReal);
                if (isSighterMode) {
                    m_xCordList_sighterMode.append(xReal);
                    m_yCordList_sighterMode.append(yReal);
                } else {
                    m_xCordList_gameMode.append(xReal);
                    m_yCordList_gameMode.append(yReal);
                }
                LogFile::instance().appendToLogFile(QString("x cor %1 and y cor %2 for shoot %3").arg(xReal).arg(yReal).arg(getShootCount() - to + i), LogType::interfaceLevel);
                emit shootCountChanged(getShootCount() - to + i);
            }

            if (m_flushCount && m_currentShootsCount == FLUSH_SHOOT_COUNT) {
//                QThread::msleep(2600);
//                clearShootCount();
                LogFile::instance().appendToLogFile(QString("Reset shoot is called, old totol shoot count %1").arg(m_oldResetCount), LogType::interfaceLevel);
                m_oldResetCount = m_oldResetCount + m_currentShootsCount;
                LogFile::instance().appendToLogFile(QString("Reset shoot is called, Current shoot count %1").arg(m_currentShootsCount), LogType::interfaceLevel);

                m_flushCount->start();

                m_currentShootsCount = 0;
                LogFile::instance().appendToLogFile(QString("Reset done, Current shoot count %1").arg(m_currentShootsCount), LogType::interfaceLevel);
            }
        }
    }
}

bool TachusWidget::isValidLicence()
{
    return true;

    QDate date = QDate::currentDate();

    QFile file("licence.txt");
    QFileInfo fInfo(file);
    qDebug() << "isValidLicence ------------" <<date.dayOfYear() <<fInfo.exists();


    //    if (date.dayOfYear() < 200 && date.year() == 2019)
    //        return true;

    //1. check for licence file if not exist return false
    if (!fInfo.exists() || !file.open(QIODevice::ReadOnly))
        return false;

    //2. check for verified word on last line
    //a. if present, already verified
    //b. if not check for

        QString testEncry = getEncryptedText("srinz", true);
        qDebug() << testEncry << " encrypted text ";
        qDebug() << getDencryptedText(testEncry, "", true);
    QTextStream stream(&file);
    int counter = 0;
    while(!stream.atEnd()) {
        QString line = stream.readLine();
        qDebug() << line;
        QString code;
        if (counter == 0) {
            code = getDencryptedText(line, "",true);
            line = code;
        } else {
            line = getDencryptedText(line, code, false);
        }

        if (line == "valid")
            return true;
        qDebug() << line;
        counter++;
    }


    file.close();
    return false;
}

void TachusWidget::uxShoot(double xCor, double yCor)
{
    LogFile::instance().appendToLogFile(QString("Ux shoot call with xCor %1 and yCor %2").arg(xCor).arg(yCor), LogType::interfaceLevel);
    m_xCordList.append(xCor);
    m_yCordList.append(yCor);
    if (isSighterMode) {
        m_xCordList_sighterMode.append(xCor);
        m_yCordList_sighterMode.append(yCor);
    } else {
        m_xCordList_gameMode.append(xCor);
        m_yCordList_gameMode.append(yCor);
    }
    m_oldResetCount++;
    emit shootCountChanged(m_oldResetCount);
}

double TachusWidget::getXCord(int index)
{
    qDebug() << __FUNCTION__ << index << m_xCordList.count();
    if (m_xCordList.isEmpty() || index == 0)
        return -1;

    if (m_xCordList.count()>= index) {
        return m_xCordList.at(index-1);
    }

    qDebug() << __FUNCTION__ << index;
    return -1;
}

double TachusWidget::getXMPI(int series)
{
    double mpi = 0;
    if (series == -1 || series == 0) // for all series
    {
        for(int i=0; i<m_xCordList.count(); ++i ) {
            mpi += m_xCordList.at(i);
        }

        mpi = mpi/m_xCordList.count();
    } else {
        int limit = (m_xCordList.count() - (series-1)*10) > 10 ? ((series-1)*10)+10 : m_xCordList.count();
        for(int i=((series-1)*10); i<limit; ++i ) {
            mpi += m_xCordList.at(i);
        }

        mpi = mpi/m_xCordList.count();
    }
    return mpi;
}

double TachusWidget::getXMPIForShoot(int series, int shootNumber)
{
    if (shootNumber >= 0 && m_xCordList.count() > shootNumber && series >= 1)
    {
        int index = ((series - 1)*10) + shootNumber;
        return m_xCordList.at(index);
    }

    return -1;
}

double TachusWidget::getYCord(int index)
{
    qDebug() << __FUNCTION__ << index;
    if (m_yCordList.isEmpty() || index == 0)
        return -1;


    ui->listWidget_2->addItem(QString("get y cord %1 index count %2").arg(index).arg(m_yCordList.count()));
    if (m_yCordList.count()>= index) {
        ui->listWidget_2->addItem(QString("get y cord value %1").arg(m_yCordList.at(index-1)));
        return m_yCordList.at(index-1);
    }

    qDebug() << __FUNCTION__ << index;
    return -1;
}

double TachusWidget::getYMPI(int series)
{
    qDebug() << __FUNCTION__;
    double mpi = 0;
    if (series == -1 || series == 0) // for all series
    {
        for(int i=0; i<m_yCordList.count(); ++i ) {
            mpi += m_yCordList.at(i);
        }

        mpi = mpi/m_yCordList.count();
    } else {
        int limit = (m_yCordList.count() - (series-1)*10) > 10 ? ((series-1)*10)+10 : m_yCordList.count();
        for(int i=((series-1)*10); i<limit; ++i ) {
            mpi += m_yCordList.at(i);
        }

        mpi = mpi/m_yCordList.count();
    }
    return mpi;
}

double TachusWidget::getYMPIForShoot(int series, int shootNumber)
{
    if (shootNumber >= 0 && m_yCordList.count() > shootNumber && series >= 1)
    {
        int index = ((series - 1)*10) + shootNumber;
        return m_yCordList.at(index);
    }

    return -1;
}

double TachusWidget::getTeiler(int series)
{
    double teiler = 0;
    if (series == -1 || series == 0) // for all series
    {
        for(int i=0; i<m_yCordList.count(); ++i ) {
            double xCor = m_xCordList.at(i);
            double yCor = m_yCordList.at(i);
            teiler += (sqrt((xCor*xCor)+(yCor*yCor)))/10;
        }

        teiler = teiler/m_yCordList.count();
    } else {
        int limit = (m_yCordList.count() - (series-1)*10) > 10 ? ((series-1)*10)+10 : m_yCordList.count();
        for(int i=((series-1)*10); i<limit; ++i ) {
            double xCor = m_xCordList.at(i);
            double yCor = m_yCordList.at(i);
            teiler += (sqrt((xCor*xCor)+(yCor*yCor)))/10;
        }

        teiler = teiler/m_yCordList.count();
    }
    return teiler;
}

double TachusWidget::getTeilerForShoot(int series, int shootNumber)
{
    if (shootNumber >= 0 && m_yCordList.count() > shootNumber && series >= 1)
    {
        int index = ((series - 1)*10) + shootNumber;

        double xCor = m_xCordList.at(index);
        double yCor = m_yCordList.at(index);

        return (sqrt((xCor*xCor)+(yCor*yCor)))/10;
    }

    return -1;
}

void TachusWidget::initiateMotorMovement()
{
    if (m_motorThread && m_mainWindow->isModBusConnected())
        m_motorThread->start();
}

void TachusWidget::intiateAutoMovementSetup()
{
    //return; // for manual motor movement && change autoMotorMovementMode in centerPane.qml to false
    LogFile::instance().appendToLogFile(QString("intiateAutoMovementSetup"), LogType::interfaceLevel);

    //    1-String to Activate Auto Paper Mode:
    //    01 06 2004 0100 01  // 2004 hex to decimal is 8196 and 0100 hex to deci is 256
    //    2-String to Set up Timer:
    //    01 06 2005 0050 01  // 2005 hex to deci is 8197 and 0250 (as we required 2500 ms) hex to deci is 592
    //    Timer: 500 ms =10ms* 0050
    //    3-String to Setup Radius Area:
    //    01 06 2006 1000 01  // 2006 hex to deci is 8198 and 1000 hex to deci is 4096
    //    Radius: 100 mm = 1/10 mm * 1000
    //start motor
    m_mainWindow->modbusWriteSingleRegister(8196, 256);
    //m_mainWindow->modbusWriteSingleRegister(8197, 293); // replace 250 (hex to deci 592) with 125 (hex to deci 293)
    QString motorDurationString = QString::number(m_motor_movement_duration*100);
    bool ok;
    uint motorDurationInt = motorDurationString.toUInt(&ok,16);
    LogFile::instance().appendToLogFile(QString("intiateAutoMovementSetup with duration %1").arg(motorDurationInt), LogType::interfaceLevel);
    m_mainWindow->modbusWriteSingleRegister(8197, motorDurationInt);
    m_mainWindow->modbusWriteSingleRegister(8198, 4096);

}

void TachusWidget::checkAutoFeedMode()
{
    LogFile::instance().appendToLogFile(QString("checkAutoFeedMode "), LogType::interfaceLevel);
    //    1-String to Activate Auto Paper Mode:
    //    01 06 2004 0100 01  // 2004 hex to decimal is 8196 and 0100 hex to deci is 256
    // 1-If Automatic Paper Feed is on or not:
    // I/P: 01 03 20 06 00 01
    uint8_t dest[1024]; //setup memory for data
    uint16_t * dest16 = (uint16_t *) dest;
    memset(dest, 0, 1024);

    m_mainWindow->modbusReadRegistry(8198, 2, dest16);
    int data_1 = dest16[1];
    int data_0 = dest16[0];
    LogFile::instance().appendToLogFile(QString("checkAutoFeedMode data[0] = %1, data[1] = %2").arg(data_0).arg(data_1), LogType::interfaceLevel);
    if (data_1 == 0 && data_0 == 0 && m_currentShootsCount <= 1) {
        showMessage("Connection Error, Please reconnect");
    }
}

void TachusWidget::showMessage(QString string)
{
    QMessageBox msgBox;
    msgBox.setWindowTitle("Error");
    msgBox.setText(string);
    msgBox.exec();
}

void TachusWidget::changeSighterMode(bool flag)
{
    //    if (!flag) {
    //        // in game more, as interchangeable is not possible
    //        // we can clean up sighter mode data

    //        m_currentShootsCount = 0;
    //        m_oldResetCount = 0;
    //        m_xCordList.clear();
    //        m_yCordList.clear();
    //    }

    //    return; //TODO - srinivas still need to work on it
    if (isSighterMode == flag)
        return;

    if (flag) {
        QList<double> temp_XCorList = m_xCordList;
        QList<double> temp_YCorList = m_yCordList;
        int m_currentShootsCount_temp = m_currentShootsCount;
        int m_oldResetCount_temp = m_oldResetCount;

        m_xCordList = m_xCordList_sighterMode;
        m_yCordList = m_yCordList_sighterMode;
        m_currentShootsCount = m_currentShootsCount_sighter;
        m_oldResetCount = m_oldResetCount_sighter;

        m_xCordList_gameMode = temp_XCorList;
        m_yCordList_gameMode = temp_YCorList;
        m_currentShootsCount_game = m_currentShootsCount_temp;
        m_oldResetCount_game = m_oldResetCount_temp;
    } else {
        QList<double> temp_XCorList = m_xCordList;
        QList<double> temp_YCorList = m_yCordList;
        int m_currentShootsCount_temp = m_currentShootsCount;
        int m_oldResetCount_temp = m_oldResetCount;

        m_xCordList = m_xCordList_gameMode;
        m_yCordList = m_yCordList_gameMode;
        m_currentShootsCount = m_currentShootsCount_game;
        m_oldResetCount = m_oldResetCount_game;

        m_xCordList_sighterMode = temp_XCorList;
        m_yCordList_sighterMode = temp_YCorList;
        m_currentShootsCount_sighter = m_currentShootsCount_temp;
        m_oldResetCount_sighter = m_oldResetCount_temp;

        // reset live/game mode
        resetShootinCount();
    }

    isSighterMode = flag;
}

void TachusWidget::appendToLogFile(QString string, LogType type)
{
    // this call is basically from QML file
    LogFile::instance().appendToLogFile(string, type);
}

void TachusWidget::connectToMaster(QString laneName)
{
    Sender sender;
    QString localhostname =  QHostInfo::localHostName();
    QString localhostIP;
    QList<QHostAddress> hostList = QHostInfo::fromName(localhostname).addresses();
    foreach (const QHostAddress& address, hostList) {
        if (address.protocol() == QAbstractSocket::IPv4Protocol && address.isLoopback() == false) {
            localhostIP = address.toString();
        }
    }
    QString localMacAddress;
    QString localNetmask;
    foreach (const QNetworkInterface& networkInterface, QNetworkInterface::allInterfaces()) {
        foreach (const QNetworkAddressEntry& entry, networkInterface.addressEntries()) {
            if (entry.ip().toString() == localhostIP) {
                localMacAddress = networkInterface.hardwareAddress();
                localNetmask = entry.netmask().toString();
                break;
            }
        }
    }

    QList<QHostAddress> list = QHostInfo::fromName(QHostInfo::localHostName()).addresses();
    for (int var = 0; var < list.size(); ++var) {
        qDebug() << list[var].toString();
    }

    LogFile::instance().appendToLogFile(QString("Lane name: %1").arg(laneName), LogType::interfaceLevel);
    LogFile::instance().appendToLogFile(QString("Localhost name:  %1").arg(localhostname), LogType::interfaceLevel);
    LogFile::instance().appendToLogFile(QString("IP =  %1").arg(localhostIP), LogType::interfaceLevel);
    LogFile::instance().appendToLogFile(QString("MAC =  %1").arg(localMacAddress), LogType::interfaceLevel);
    LogFile::instance().appendToLogFile(QString("Netmask =  %1").arg(localNetmask), LogType::interfaceLevel);

    QString data = QString("laneName-%1 systemName-%2 ip-%3 mac-%4 netmask-%5")
            .arg(laneName)
            .arg(localhostname)
            .arg(localhostIP)
            .arg(localMacAddress)
            .arg(localNetmask);
    sender.broadcastDatagram(data);
}

void TachusWidget::startTCP()
{
    m_tcpServer = new QTcpServer();
}

void TachusWidget::stopTCP()
{
    delete m_tcpServer;
    if (m_tcpServer != nullptr)
        m_tcpServer = nullptr;
}

void TachusWidget::on_pushButton_3_clicked()
{
    // no action
}

void TachusWidget::checkForNewShots(bool motorAutoMode)
{
    //LogFile::instance().appendToLogFile("Checking for new shoots", LogType::BackendLevel);
    uint8_t dest[1024]; //setup memory for data
    uint16_t * dest16 = (uint16_t *) dest;
    memset(dest, 0, 1024);

    m_mainWindow->modbusReadRegistry(8192, 2, dest16);
    int newShotsCount = dest16[1];
    //motorAutoMode = false;
    if (newShotsCount > m_currentShootsCount)
    {
        LogFile::instance().appendToLogFile(QString("Current shoot count %1 while old shoot count was %2").arg(newShotsCount).arg(m_currentShootsCount), LogType::BackendLevel);
        m_currentShootsCount = newShotsCount;
    }
}

int TachusWidget::getRealValue(int value)
{
    int decimal = value;
    bool ok;
    QString hex = QString::number(decimal, 16);
    int hexNum = hex.toInt(&ok, 16);
    QString binary = QString::number(hexNum, 2);
    QString binaryRightEight = binary.right(8);
    //qDebug() << "-----------------------***" << binaryRightEight;
    QString binary2C;
    if (binary.at(0) == "1" && binary.length() == 16)
    {
        for (int i=0; i<16; i++)
        {
            if (binary.at(i) == "1")
                binary2C.append("0");
            else
                binary2C.append("1");
        }
        int realValue = binary2C.toInt(&ok, 2);
        return (realValue+1)*(-1);
    } else
        return decimal;
}

void TachusWidget::clearShootCount()
{
    LogFile::instance().appendToLogFile(QString("Reset shoot is called, old totol shoot count %1").arg(m_oldResetCount), LogType::interfaceLevel);
    m_oldResetCount = m_oldResetCount + m_currentShootsCount;
    LogFile::instance().appendToLogFile(QString("Reset shoot is called, Current shoot count %1").arg(m_currentShootsCount), LogType::interfaceLevel);
    // reset the hardware
    // register 2001 Hex = 8193 decimal
    m_mainWindow->modbusWriteSingleRegister(8193, 0);
    //checkForNewShots();
    m_currentShootsCount = 0;
    LogFile::instance().appendToLogFile(QString("Reset done, Current shoot count %1").arg(m_currentShootsCount), LogType::interfaceLevel);
}

QString TachusWidget::getEncryptedText(QString data, bool onlyDefault)
{
    QString result;

    if (onlyDefault) {
        //result.append(data.toUtf8());
        for (int i=0; i<data.size(); ++i) {
            result.append(data.at(i).unicode()+ENCRYPTION_DEFAULT);
        }
    } else {
//        for (int i=0; i<data.size(); ++i) {
//            int curIndex = i%m_encryption_text.size();
//            result.append(data.at(i).toLatin1()+m_encryption_text.at(curIndex).toLatin1());
//        }
    }

    return result;
}

QString TachusWidget::getDencryptedText(QString data, QString encryptionText, bool onlyDefault)
{
    QString result;

    //if (onlyDefault) {
        for (int i=0; i<data.size(); ++i) {
            result.append(((data.at(i).unicode()-ENCRYPTION_DEFAULT)));
        }
//    } else {
//        for (int i=0; i<data.size(); ++i) {
//            int curIndex = i%encryptionText.size();
//            result.append(data.at(i).unicode()-encryptionText.at(curIndex).unicode());
//        }
//    }

        return result;
}

void TachusWidget::licValidated()
{
    QFile file("licence.txt");
    QFileInfo fInfo(file);

    if (!fInfo.exists() || !file.open(QIODevice::Append))
        return;

    QTextStream stream(&file);
    stream << endl;
    stream << getEncryptedText("valid", true);
    file.close();
}
