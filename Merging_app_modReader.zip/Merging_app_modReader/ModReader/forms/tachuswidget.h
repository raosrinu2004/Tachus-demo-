#ifndef TACHUSWIDGET_H
#define TACHUSWIDGET_H

#include <QWidget>
#include <QTimer>
#include <QThread>
#include <QDebug>
#include <QMessageBox>
#include <QTcpServer>

#include "../src/mainwindow.h"
#include "logfile.h"

#define FLUSH_SHOOT_COUNT 10

namespace Ui {
class TachusWidget;
}

class MotorThread : public QThread
{
public:
    explicit MotorThread(MainWindow* mainWindow, QObject* parent = 0)
        : m_mainWindow(mainWindow), QThread(parent)
    {
    }
    ~MotorThread() {

    }
    void setMotorMovementTime(double time) {
        motor_movement_time = time;
    }

protected:
    void run() override {
        startMotor();
        QThread::msleep(motor_movement_time*1000);
        stopMotor();
    }

private:
    void startMotor() {
        //start motor
        LogFile::instance().appendToLogFile("Send motor movement signal", LogType::BackendLevel);

        m_mainWindow->modbusWriteSingleRegister(8196, 32768);
        QThread::msleep(100);

        //while loop to check, motor status
        bool motorStarted = false;
        while (!motorStarted)
        {
            uint8_t dest[1024]; //setup memory for data
            uint16_t * dest16 = (uint16_t *) dest;
            memset(dest, 0, 1024);


            m_mainWindow->modbusReadRegistry(8196, 2, dest16);
            motorStarted = dest16[0] == 32768 ? true : false;
            LogFile::instance().appendToLogFile(motorStarted ? QString("Reading motor status -> started") :
                                                             QString("Reading motor status -> not-started"), LogType::BackendLevel);
//            QMessageBox msgBox;
//            msgBox.setText(QString("%1 From Start - is motor running %2").arg(dest16[0]).arg(dest16[1]));
//            msgBox.exec();
        }

    }

    void stopMotor() {
        // stop motor
        LogFile::instance().appendToLogFile("Send motor stop signal", LogType::BackendLevel);
        QThread::msleep(100);

        m_mainWindow->modbusWriteSingleRegister(8196, 0);
        //while loop to check, motor status
        bool motorStoped = false;
        while (!motorStoped)
        {
            uint8_t dest[1024]; //setup memory for data
            uint16_t * dest16 = (uint16_t *) dest;
            memset(dest, 0, 1024);

            m_mainWindow->modbusReadRegistry(8196, 2, dest16);
            motorStoped = (dest16[0] == 0) ? true : false;
            LogFile::instance().appendToLogFile(motorStoped ? QString("Reading motor status -> stoped") :
                                                        QString("Reading motor status -> not-stoped"), LogType::BackendLevel);

//            QMessageBox msgBox;
//            msgBox.setText(QString("%1 From Stop - is motor running %2").arg(dest16[0]).arg(dest16[1]));
//            msgBox.exec();
        }
    }
private:
    MainWindow* m_mainWindow;
    double motor_movement_time = 0;
//    TachusWidget* tachusWidget = NULL;
};

// flush hardware shoot wount
//////////////////////////////////////
/// \brief The FlushShootCountThread class
//////////////////////////////////////

class TachusWidget;
class FlushShootCountThread : public QThread
{
public:
    explicit FlushShootCountThread(MainWindow* mainWindow, QObject* parent = 0)
        : m_mainWindow(mainWindow), QThread(parent)
    {
    }
    ~FlushShootCountThread() {
    }

protected:
    void run() override {
        QThread::msleep(2600);
        //m_tachusWidget->clearShootCount();

        //
        // reset the hardware
        // register 2001 Hex = 8193 decimal
        m_mainWindow->modbusWriteSingleRegister(8193, 0);
    }

private:
    MainWindow* m_mainWindow;
};

////////////////////////////////
/// \brief The TachusWidget class
///
////////////////////////////////

class TachusWidget : public QWidget
{
    Q_OBJECT

public:
    explicit TachusWidget(MainWindow* mainwindow, QWidget *parent = 0);
    ~TachusWidget();
    void initialiseConnection();
    void setMotorMovementTime(double time) {
        if (m_motorThread)
            m_motorThread->setMotorMovementTime(time);
        m_motor_movement_duration = time;
    }

public slots:
    bool isModBusConnected();
    bool isMasterSystemConnected();
    bool connectedModbus(QString portName = QString());
    int validateLicence(QString mail);
    bool disconnectModbus();
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    bool isValidLicence();
    void uxShoot(double xCor, double yCor);
    int getShootCount() {
        return m_oldResetCount + m_currentShootsCount;
    }

    double getXCord(int index);
    double getXMPI(int series = -1);
    double getXMPIForShoot(int series, int shootNumber);
    double getYCord(int index);
    double getYMPI(int series = -1);
    double getYMPIForShoot(int series, int shootNumber);
    double getTeiler(int series = -1);
    double getTeilerForShoot(int series, int shootNumber = -1);
    void initiateMotorMovement();
    void resetShootinCount() {
        m_currentShootsCount = 0;
        m_oldResetCount = 0;
        m_mainWindow->modbusWriteSingleRegister(8193, 0);
    }

    void intiateAutoMovementSetup();
    void checkAutoFeedMode();
    void showMessage(QString string);
    void changeSighterMode(bool flag);
    void appendToLogFile(QString string, LogType type = LogType::UXLevel);
    void connectToMaster(QString laneName);
    void startTCP();
    void stopTCP();

private slots:
    void on_pushButton_3_clicked();
    void checkForNewShots(bool motorAutoMode = true);
    int getRealValue(int value);

private:
    void clearShootCount();
    QString getEncryptedText(QString data, bool onlyDefault=false);
    QString getDencryptedText(QString data, QString encryptionText, bool onlyDefault=false);
    void licValidated();

signals:
    void shootCountChanged(int count);

private:
    Ui::TachusWidget *ui;
    MainWindow* m_mainWindow;
    int m_currentShootsCount = 0;
    int m_oldResetCount = 0;
    QTimer* m_timer = NULL;
    bool autoModeOn = false;
    bool isSighterMode = false; // as in contructor we would initialise with true
    QList<double> m_xCordList;
    QList<double> m_yCordList;
    QList<double> m_xCordList_gameMode;
    QList<double> m_yCordList_gameMode;
    QList<double> m_xCordList_sighterMode;
    QList<double> m_yCordList_sighterMode;
    int m_currentShootsCount_game = 0;
    int m_oldResetCount_game = 0;
    int m_currentShootsCount_sighter = 0;
    int m_oldResetCount_sighter = 0;
    MotorThread* m_motorThread = nullptr;
    FlushShootCountThread* m_flushCount = nullptr;

    QTcpServer* m_tcpServer = nullptr;
    double m_motor_movement_duration = 2.5;
};

#endif // TACHUSWIDGET_H
