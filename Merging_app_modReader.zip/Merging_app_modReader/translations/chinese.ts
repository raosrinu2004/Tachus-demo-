<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>About</name>
    <message>
        <location filename="../ModReader/forms/about.ui" line="26"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/about.ui" line="62"/>
        <source>lib version</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BusMonitor</name>
    <message>
        <location filename="../ModReader/forms/busmonitor.ui" line="29"/>
        <source>Bus Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/busmonitor.ui" line="48"/>
        <source>Raw Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/busmonitor.ui" line="135"/>
        <location filename="../ModReader/forms/busmonitor.ui" line="138"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/busmonitor.ui" line="150"/>
        <location filename="../ModReader/forms/busmonitor.ui" line="153"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/busmonitor.ui" line="162"/>
        <location filename="../ModReader/forms/busmonitor.ui" line="165"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CenterPane</name>
    <message>
        <location filename="../CenterPane.qml" line="15"/>
        <source>PISTOL</source>
        <translation type="unfinished">手枪</translation>
    </message>
    <message>
        <location filename="../CenterPane.qml" line="763"/>
        <source>Final shot of the match</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClosePopupDialog</name>
    <message>
        <location filename="../ClosePopupDialog.qml" line="23"/>
        <source>The Match is finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ClosePopupDialog.qml" line="30"/>
        <source>Do you want to save your match?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Header</name>
    <message>
        <location filename="../Header.qml" line="56"/>
        <source>SHOOT ON TACHUS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Header.qml" line="56"/>
        <source>SHOOT ON SETA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LeftPanel</name>
    <message>
        <location filename="../LeftPanel.qml" line="471"/>
        <source>Device connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="471"/>
        <source>Device not connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="481"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="491"/>
        <source>Match report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="501"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="511"/>
        <source>Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="526"/>
        <source>SIGHTER</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LoginPage</name>
    <message>
        <location filename="../LoginPage.qml" line="134"/>
        <source>10 Shots Match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="136"/>
        <source>20 Shots Match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="138"/>
        <source>30 Shots Match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="140"/>
        <source>40 Shots Match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="142"/>
        <source>60 Shots Match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="144"/>
        <source>Free Practice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="218"/>
        <source>Upload image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="879"/>
        <source>EVENT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="892"/>
        <source>PISTOL</source>
        <translation>手枪</translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="906"/>
        <source>RIFLE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="920"/>
        <source>START</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="930"/>
        <source>RESET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="940"/>
        <source>Device connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="940"/>
        <source>Device not connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="951"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="963"/>
        <source>Saved files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="975"/>
        <source>User guide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LoginPage.qml" line="986"/>
        <source>Contact us</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="26"/>
        <source>QModMaster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="63"/>
        <source>Modbus Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="90"/>
        <source>Slave Addr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="116"/>
        <source>Scan Rate (ms)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="177"/>
        <source>Read Coils (0x01)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="182"/>
        <source>Read Discrete Inputs (0x02)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="187"/>
        <source>Read Holding Registers (0x03)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="192"/>
        <source>Read Input Registers (0x04)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="197"/>
        <source>Write Single Coil (0x05)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="202"/>
        <source>Write Single Register (0x06)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="207"/>
        <source>Write Multiple Coils (0x0f)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="212"/>
        <source>Write Multiple Registers (0x10)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="220"/>
        <source>Function Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="246"/>
        <source>Start Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="273"/>
        <location filename="../ModReader/forms/mainwindow.ui" line="309"/>
        <location filename="../ModReader/forms/mainwindow.ui" line="321"/>
        <source>Dec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="278"/>
        <location filename="../ModReader/forms/mainwindow.ui" line="326"/>
        <source>Hex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="286"/>
        <source>Number of Coils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="316"/>
        <source>Bin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="334"/>
        <source>Data Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="376"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="385"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="394"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="401"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="408"/>
        <source>Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="450"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="486"/>
        <source>About...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="498"/>
        <source>Bus Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="510"/>
        <source>Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="522"/>
        <source>Read / Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="535"/>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="547"/>
        <source>Scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="556"/>
        <source>Reset Counters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="610"/>
        <source>Log File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="619"/>
        <source>Clear Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="628"/>
        <source>Modbus Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="637"/>
        <source>Load Session...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/mainwindow.ui" line="646"/>
        <source>Save Session...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MatchReport</name>
    <message>
        <location filename="../MatchReport.qml" line="121"/>
        <source>Match Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReport.qml" line="211"/>
        <source>REPORTS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MatchReportInfo</name>
    <message>
        <location filename="../MatchReportInfo.qml" line="60"/>
        <source>Shooter Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="123"/>
        <source>Total Score</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="135"/>
        <location filename="../MatchReportInfo.qml" line="271"/>
        <source>Average score</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="240"/>
        <source>SERIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="259"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="284"/>
        <source>Total Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="296"/>
        <source>Average Time/shot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="322"/>
        <source>Sr No.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="328"/>
        <source>Score</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="334"/>
        <source>MPI X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="340"/>
        <source>MPI Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="346"/>
        <source>Teiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MatchReportInfo.qml" line="352"/>
        <source>Time stamp</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page1Form.ui</name>
    <message>
        <location filename="../Page1Form.ui.qml" line="16"/>
        <source>Text Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Page1Form.ui.qml" line="21"/>
        <source>Press Me</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PdfPage</name>
    <message>
        <location filename="../PdfPage.qml" line="9"/>
        <source>Page </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PdfSeriesPage</name>
    <message>
        <location filename="../PdfSeriesPage.qml" line="9"/>
        <source>Page </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RightPanel</name>
    <message>
        <location filename="../RightPanel.qml" line="930"/>
        <source>SERIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../RightPanel.qml" line="944"/>
        <source>SN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../RightPanel.qml" line="954"/>
        <source>Score</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../RightPanel.qml" line="964"/>
        <source>Time (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../RightPanel.qml" line="985"/>
        <source>TOTAL SCORE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../RightPanel.qml" line="1000"/>
        <source>Series Performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../RightPanel.qml" line="1018"/>
        <source>Time (m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../RightPanel.qml" line="1035"/>
        <source>Match Performance</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../ModReader/forms/settings.ui" line="32"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settings.ui" line="54"/>
        <source>Response Timeout (sec)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settings.ui" line="82"/>
        <source>Max No Of Bus Monitor Lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settings.ui" line="136"/>
        <source>Base Addr</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsModbusRTU</name>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="26"/>
        <source>Modbus RTU Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="47"/>
        <source>Serial port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="57"/>
        <source>Parity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="96"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="101"/>
        <source>Odd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="106"/>
        <source>Even</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="117"/>
        <source>Stop Bits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="140"/>
        <source>Data Bits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="267"/>
        <source>Baud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="280"/>
        <source>Serial device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="291"/>
        <source>/dev/ttyS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbusrtu.ui" line="296"/>
        <source>/dev/ttyUSB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsModbusTCP</name>
    <message>
        <location filename="../ModReader/forms/settingsmodbustcp.ui" line="26"/>
        <source>Modbus TCP Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbustcp.ui" line="41"/>
        <source>Slave IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/settingsmodbustcp.ui" line="48"/>
        <source>TCP Port</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SummaryPage</name>
    <message>
        <location filename="../SummaryPage.qml" line="111"/>
        <source>Date and Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SummaryPage.qml" line="121"/>
        <source>Shooter Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SummaryPage.qml" line="131"/>
        <source>Event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SummaryPage.qml" line="140"/>
        <source>Total Shots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SummaryPage.qml" line="149"/>
        <source>Total Score</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SummaryPage.qml" line="158"/>
        <source>Average score</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SummaryPage.qml" line="167"/>
        <source>Average Time/Shot (In minutes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SummaryPage.qml" line="178"/>
        <source>Series wise total</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TachusWidget</name>
    <message>
        <location filename="../ModReader/forms/tachuswidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/tachuswidget.ui" line="24"/>
        <source>Capture Shots details From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/tachuswidget.ui" line="34"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/tachuswidget.ui" line="44"/>
        <source>Start Reading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/tachuswidget.ui" line="55"/>
        <source>X cords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/tachuswidget.ui" line="67"/>
        <source>Y Cords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/tachuswidget.ui" line="85"/>
        <source>Start Motor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ModReader/forms/tachuswidget.ui" line="92"/>
        <source>Stop Motor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="12"/>
        <source>Hello World</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="39"/>
        <source>10M AIR RIFLE FREE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="41"/>
        <location filename="../main.qml" line="48"/>
        <location filename="../main.qml" line="55"/>
        <location filename="../main.qml" line="62"/>
        <location filename="../main.qml" line="69"/>
        <location filename="../main.qml" line="76"/>
        <location filename="../main.qml" line="83"/>
        <location filename="../main.qml" line="90"/>
        <location filename="../main.qml" line="97"/>
        <location filename="../main.qml" line="104"/>
        <location filename="../main.qml" line="111"/>
        <location filename="../main.qml" line="118"/>
        <source>10M AIR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="42"/>
        <location filename="../main.qml" line="49"/>
        <location filename="../main.qml" line="56"/>
        <location filename="../main.qml" line="63"/>
        <location filename="../main.qml" line="70"/>
        <location filename="../main.qml" line="77"/>
        <source>RIFLE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="43"/>
        <location filename="../main.qml" line="85"/>
        <source>UN-LIMITED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="46"/>
        <source>10M AIR RIFLE 10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="50"/>
        <location filename="../main.qml" line="92"/>
        <source>MATCH-10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="53"/>
        <source>10M AIR RIFLE 20</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="57"/>
        <location filename="../main.qml" line="99"/>
        <source>MATCH-20</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="60"/>
        <source>10M AIR RIFLE 30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="64"/>
        <location filename="../main.qml" line="106"/>
        <source>MATCH-30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="67"/>
        <source>10M AIR RIFLE 40</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="71"/>
        <location filename="../main.qml" line="113"/>
        <source>MATCH-40</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="74"/>
        <source>10M AIR RIFLE 60</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="78"/>
        <location filename="../main.qml" line="120"/>
        <source>MATCH-60</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="81"/>
        <source>10M AIR PISTOL FREE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="84"/>
        <location filename="../main.qml" line="91"/>
        <location filename="../main.qml" line="98"/>
        <location filename="../main.qml" line="105"/>
        <location filename="../main.qml" line="112"/>
        <location filename="../main.qml" line="119"/>
        <source>PISTOL</source>
        <translation type="unfinished">手枪</translation>
    </message>
    <message>
        <location filename="../main.qml" line="88"/>
        <source>10M AIR PISTOL 10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="95"/>
        <source>10M AIR PISTOL 20</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="102"/>
        <source>10M AIR PISTOL 30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="109"/>
        <source>10M AIR PISTOL 40</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="116"/>
        <source>10M AIR PISTOL 60</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
